# conftest.py
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
# Asumo que 'Base' está en src.database. Si se llama distinto, ajusta la importación.
from src.database import Base 
import src.veterinarios  # Importamos el módulo que queremos testear

# Usamos SQLite en memoria para máxima velocidad y aislamiento
TEST_DATABASE_URL = "sqlite:///:memory:"

@pytest.fixture(scope="session")
def engine():
    """Crea el motor de BD una sola vez por sesión de pruebas"""
    return create_engine(TEST_DATABASE_URL, connect_args={"check_same_thread": False})

@pytest.fixture(scope="function")
def session(engine):
    """
    Crea una sesión nueva para CADA test individual.
    Al terminar el test, borra las tablas para dejar todo limpio.
    """
    # 1. Crear las tablas en la BD de memoria
    Base.metadata.create_all(engine)
    
    # 2. Crear la sesión
    Session = sessionmaker(bind=engine)
    session = Session()
    
    # 3. TRUCO (Monkeypatching):
    # Reemplazamos la 'session' que usa src.veterinarios por NUESTRA session de prueba.
    # Así, cuando el código ejecute session.add(), lo hará en la BD de memoria.
    src.veterinarios.session = session
    
    yield session  # Aquí es donde se ejecuta el test
    
    # 4. Limpieza post-test
    session.close()
    Base.metadata.drop_all(engine)